package com.example.geminilite

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private lateinit var rvChat: RecyclerView
    private lateinit var etMessage: EditText
    private lateinit var btnSend: Button
    private lateinit var tvEmail: TextView
    private lateinit var btnLogout: Button

    private val chatList = ArrayList<ChatMessage>()
    private lateinit var chatAdapter: ChatAdapter
    private val historyList = ArrayList<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat)

        // 🔹 Firebase Auth


        // 🔹 Bind UI
        rvChat = findViewById(R.id.rvChat)
        etMessage = findViewById(R.id.etMessage)
        btnSend = findViewById(R.id.btnSend)
        tvEmail = findViewById(R.id.tvEmail)
        btnLogout = findViewById(R.id.btnLogout)

        val btnHistory = findViewById<Button>(R.id.btnHistory)

        btnHistory.setOnClickListener {
            val intent = Intent(this, HistoryActivity::class.java)
            intent.putStringArrayListExtra("history", historyList)
            startActivity(intent)
        }

        // 🔹 Tampilkan email user
        tvEmail.text = "Login sebagai: ${auth.currentUser?.email ?: "Guest"}"

        // 🔹 Logout
        btnLogout.setOnClickListener {
            auth.signOut()
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }

        // 🔹 RecyclerView setup
        rvChat.setHasFixedSize(true)
        chatAdapter = ChatAdapter(chatList)
        rvChat.layoutManager = LinearLayoutManager(this).apply { stackFromEnd = true }
        rvChat.adapter = chatAdapter

        // 🔹 Send message
        btnSend.setOnClickListener {
            val userMessage = etMessage.text.toString().trim()
            if (userMessage.isNotEmpty()) {
                addMessage(userMessage, true)
                historyList.add(userMessage)
                etMessage.setText("")

                // Dummy response
                addMessage(getDummyResponse(userMessage), false)
            }
        }

        // 🔹 Pesan awal bot
        if (chatList.isEmpty()) {
            addMessage("Halo 👋 Saya Gemini Lite, ada yang bisa saya bantu?", false)
        }
    }

    private fun addMessage(message: String, isUser: Boolean) {
        chatList.add(ChatMessage(message, isUser))
        chatAdapter.notifyItemInserted(chatList.size - 1)
        rvChat.scrollToPosition(chatList.size - 1)
    }

    private fun getDummyResponse(userMessage: String): String {
        return when {
            userMessage.contains("halo", true) ->
                "Halo! Saya Gemini Lite 😊"
            userMessage.contains("apa kabar", true) ->
                "Saya baik, terima kasih! Ada yang bisa saya bantu?"
            userMessage.contains("nama", true) ->
                "Nama saya Gemini Lite 🤖"
            else ->
                "Maaf, Gemini Lite versi ini masih sederhana."
        }
    }
}
