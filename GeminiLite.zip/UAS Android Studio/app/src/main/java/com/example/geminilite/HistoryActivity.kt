package com.example.geminilite

import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class HistoryActivity : AppCompatActivity() {

    private lateinit var rvHistory: RecyclerView
    private val historyList = ArrayList<String>()
    private lateinit var historyAdapter: HistoryAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history)

        rvHistory = findViewById(R.id.rvHistory)
        rvHistory.layoutManager = LinearLayoutManager(this)
        historyAdapter = HistoryAdapter(historyList)
        rvHistory.adapter = historyAdapter

        // 🔹 Ambil data dari intent (MainActivity)
        val questions = intent.getStringArrayListExtra("history")
        if (questions != null) {
            historyList.addAll(questions)
            historyAdapter.notifyDataSetChanged()
        }

        // 🔹 BUTTON HAPUS RIWAYAT
        val btnClear = findViewById<Button>(R.id.btnClearHistory)
        btnClear.setOnClickListener {
            showClearConfirmDialog()
        }
    }

    // 🔹 DIALOG KONFIRMASI
    private fun showClearConfirmDialog() {
        AlertDialog.Builder(this)
            .setTitle("Konfirmasi")
            .setMessage("Yakin ingin menghapus semua riwayat?")
            .setPositiveButton("Ya") { _, _ ->
                clearHistory()
            }
            .setNegativeButton("Batal") { dialog, _ ->
                dialog.dismiss()
            }
            .setCancelable(false)
            .show()
    }

    // 🔹 HAPUS DATA RIWAYAT
    private fun clearHistory() {
        historyList.clear()
        historyAdapter.notifyDataSetChanged()
        Toast.makeText(this, "Riwayat berhasil dihapus", Toast.LENGTH_SHORT).show()
    }
}
