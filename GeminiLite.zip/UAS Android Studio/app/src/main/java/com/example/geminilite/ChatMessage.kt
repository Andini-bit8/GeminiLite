package com.example.geminilite

data class ChatMessage(
    val message: String,
    val isUser: Boolean
)

